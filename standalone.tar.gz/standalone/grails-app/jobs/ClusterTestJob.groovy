class ClusterTestJob {

	boolean volatility = false

	long timeout = 2000
//	static triggers = {
//		simple repeatInterval: 2000  
//	}

	void execute() {
		String instance = System.getProperty('catalina.instance')
		if (instance) {
			println "running in instance $instance at ${new Date()}"
		}
		else {
			println "running standalone at ${new Date()}"
		}
	}
}
