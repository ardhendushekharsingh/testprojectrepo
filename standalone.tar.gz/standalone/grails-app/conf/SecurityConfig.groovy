security {

	active = true

	loginUserDomainClass = 'com.burtbeckwith.clusterdemo.User'
	authorityDomainClass = 'com.burtbeckwith.clusterdemo.Role'

	useRequestMapDomainClass = false
	useControllerAnnotations = true
}
