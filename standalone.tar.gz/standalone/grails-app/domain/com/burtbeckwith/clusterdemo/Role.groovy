package com.burtbeckwith.clusterdemo

/**
 * Authority domain class.
 */
class Role {

	static hasMany = [people: User]

	String description
	String authority

	static constraints = {
		authority blank: false, unique: true
	}
}
