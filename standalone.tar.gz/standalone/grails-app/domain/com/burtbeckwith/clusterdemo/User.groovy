package com.burtbeckwith.clusterdemo

/**
 * User domain class.
 */
class User {

	static hasMany = [authorities: Role]
	static belongsTo = Role

	String username
	String passwd
	boolean enabled

	static constraints = {
		username blank: false, unique: true
		passwd blank: false
	}
}
